#!/bin/bash

# Simple installation script

TOOL_DIR="${HOME}/ios-backup-tool"

echo "Creating directory structure..."
mkdir -p "${TOOL_DIR}/backups"
mkdir -p "${TOOL_DIR}/logs"
mkdir -p "${TOOL_DIR}/config"
mkdir -p "${TOOL_DIR}/bin"

echo "Copying main script..."
cp ios-backup-tool "${TOOL_DIR}/bin/"
chmod +x "${TOOL_DIR}/bin/ios-backup-tool"

echo "Creating config file..."
cat > "${TOOL_DIR}/config/config.conf" << EOF
# iOS Backup Tool Configuration
COMPRESSION_LEVEL=6
KEEP_BACKUPS=10
ENCRYPT_BACKUPS=false
LOG_LEVEL="INFO"
EOF

echo "Creating symlink in ~/bin..."
mkdir -p ~/bin
ln -sf "${TOOL_DIR}/bin/ios-backup-tool" ~/bin/ios-backup-tool

echo "Adding ~/bin to PATH..."
if ! grep -q "export PATH=\"\$HOME/bin:\$PATH\"" ~/.bashrc; then
    echo 'export PATH="$HOME/bin:$PATH"' >> ~/.bashrc
fi

if ! grep -q "export PATH=\"\$HOME/bin:\$PATH\"" ~/.zshrc; then
    echo 'export PATH="$HOME/bin:$PATH"' >> ~/.zshrc
fi

echo ""
echo "Installation complete!"
echo "Tool installed to: ${TOOL_DIR}"
echo ""
echo "Please run: source ~/.bashrc"
echo "Then you can use: ios-backup-tool install-deps"