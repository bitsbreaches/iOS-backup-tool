1. Install the tool:

```
chmod +x install.sh
./install.sh
ios-backup-tool install-deps
```

2. Backup your iOS device:

```
ios-backup-tool backup
```

3. List available backups:

```
ios-backup-tool list
```

4. Restore from backup:

```
ios-backup-tool restore /path/to/backup
```

5. Clean up old backups:

```
ios-backup-tool clean 5
```

6. Features
- Automatic device detection
- Encrypted backup support
- Automatic cleanup of old backups
- Comprehensive logging
- Configuration management
- Device information display
- Cross-distribution support

7. Dependencies
The tool requires libimobiledevice utilities:

bash
```
sudo apt install libimobiledevice6 libimobiledevice-utils
```

8. Security Notes
- Backups are stored in your home directory
- Encryption uses Apple's built-in encryption when enabled
- Always test restores with non-critical data first